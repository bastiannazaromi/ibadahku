<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_login extends CI_Model {
    
}

/* End of file Model_informasi.php */
