<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Rekap extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
		siswa_init();
	}
	public function index()
	{
		$tanggal	= $this->u3;

		if (!$tanggal) {
			$tanggal = date('Y-m-d');
		}

		$date = strtotime($tanggal);
		$hari = date('N', $date);

		$params = [
			'title'     	=> 'Rekap Kegiatan Siswa',
			'tanggal'		=> $tanggal,
			'hari'			=> hari($hari),
			'kategori'		=> $this->universal->getMulti('', 'kategori')
		];

		$this->load->view('rekap', $params);
	}
}
