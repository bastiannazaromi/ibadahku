<script src="<?= $one->assets_folder; ?>/js/oneui.core.min.js"></script>
<script src="<?= $one->assets_folder; ?>/js/oneui.app.min.js"></script>