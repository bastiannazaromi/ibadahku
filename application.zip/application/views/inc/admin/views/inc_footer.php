<footer id="page-footer" class="bg-body-light">
    <div class="content py-3">
        <div class="row font-size-sm">
            <div class="col-sm-6 order-sm-2 py-1 text-center text-sm-right">
                <span class="font-w600">Sekolah Dasar Negeri Kupu 02</span>
            </div>
            <div class="col-sm-6 order-sm-1 py-1 text-center text-sm-left">
                <span class="font-w600">Copyright &copy; <span data-toggle="year-copy"></span> - <?= $one->name . ' ' . $one->version; ?> </span>
            </div>
        </div>
    </div>
</footer>